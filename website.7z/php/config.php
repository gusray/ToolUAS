<?php 
                        
 $con = mysqli_connect("localhost","root","","website") or die("Couldn't connect");

?>